[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(CIBPhonebook.Web.MVCGridConfig), "RegisterGrids")]

namespace CIBPhonebook.Web
{
    using CIBPhonebook.Utilities;
    using CIBPhonebook.Web.Models;
    using MVCGrid.Models;
    using MVCGrid.Web;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;

    public static class MVCGridConfig
    {
        public const string PHONEBOOK_ENTRIES_GRID = nameof(PHONEBOOK_ENTRIES_GRID);
        public static void RegisterGrids()
        {
            MVCGridDefinitionTable.Add(PHONEBOOK_ENTRIES_GRID, new MVCGridBuilder<ViewPagedPhoneBookEntries>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames(nameof(ViewPagedPhonebookRequest.SearchAll), nameof(ViewPagedPhonebookRequest.PhoneBookId))
            .AddColumns(cols =>
            {
                cols.Add(nameof(ViewPagedPhoneBookEntries.PhoneBookEntryID))
                .WithValueExpression((p, c) => Convert.ToString(p.PhoneBookEntryID));

                cols.Add(nameof(ViewPagedPhoneBookEntries.PhonebookName)).WithHeaderText("Phonebook Name")
                    .WithVisibility(true, true)
                    .WithValueExpression(p => p.PhonebookName);

                cols.Add(nameof(ViewPagedPhoneBookEntries.EntryName)).WithHeaderText("Entry Name")
                    .WithVisibility(true, true)
                    .WithValueExpression(p => p.EntryName);

                cols.Add(nameof(ViewPagedPhoneBookEntries.PhoneNumber)).WithHeaderText("PhoneNumber")
                    .WithValueExpression(p => p.PhoneNumber);

            })
            .WithRetrieveDataMethod((context) =>
            {
                int pageSize = context.QueryOptions.GetLimitRowcount() ?? 15;
                int limitOffset = context.QueryOptions.GetLimitOffset() ?? 0;
                int pageIndex = 1;
                if (limitOffset > 0)
                    pageIndex = (limitOffset / pageSize) + 1;
                ViewPagedPhonebookRequest PageRequestDTO = new ViewPagedPhonebookRequest();
                PageRequestDTO.PageSize = pageSize;
                PageRequestDTO.PageNumber = pageIndex;

                {    //add 'SearchAll' parameter 
                    string SearchAllParameter = context.QueryOptions.GetAdditionalQueryOptionString(nameof(ViewPagedPhonebookRequest.SearchAll));
                    if (!string.IsNullOrWhiteSpace(SearchAllParameter))
                    {
                        PageRequestDTO.SearchAll = SearchAllParameter;
                    }
                }

                {   // //add 'PhoneBookId' parameter 
                    string PhoneBookIdParameter = context.QueryOptions.GetAdditionalQueryOptionString(nameof(ViewPagedPhonebookRequest.PhoneBookId));
                    if (int.TryParse(PhoneBookIdParameter, out int PhoneBookId) && PhoneBookId > 0)
                    {
                        PageRequestDTO.PhoneBookId = PhoneBookId;
                    }
                }

                ViewPagedPhonebookResponse apiResponseObject = new ViewPagedPhonebookResponse();
                StandardAPIResponse apiResponse = APIHelper.PhoneBookEntityAPI.GetPhoneBookEntriesByParamsPaged(PageRequestDTO);
                if (apiResponse.HasSuccessResult && !apiResponse.ResultIsNull)
                {
                    //'Result.Deserialise' is not a standard method but rather a extension method i added to make life easier
                    apiResponseObject = apiResponse.Result.Deserialise<ViewPagedPhonebookResponse>();
                    return new QueryResult<ViewPagedPhoneBookEntries>()
                    {
                        Items = apiResponseObject.PagedData,
                        TotalRecords = apiResponseObject.TotalRecords
                    };
                }
                else
                    return new QueryResult<ViewPagedPhoneBookEntries>()
                    {
                        Items = new List<ViewPagedPhoneBookEntries>(),
                        TotalRecords = 0
                    };
            }));
        }
    }
}