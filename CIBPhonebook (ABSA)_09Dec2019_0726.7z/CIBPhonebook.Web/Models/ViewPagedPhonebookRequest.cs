﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.Web.Models
{
    public class ViewPagedPhonebookRequest
    {
        public string SearchAll { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        //Filter Parameters
        public int PhoneBookId { get; set; }
    }
}