﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.Web.Models
{
    public class ViewPagedPhonebookResponse
    {
        public int TotalRecords { get; set; }
        public List<ViewPagedPhoneBookEntries> PagedData { get; set; }
    }
}