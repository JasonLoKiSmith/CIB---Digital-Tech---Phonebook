﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.Web.Models
{
    public class ViewPagedPhoneBookEntries
    {
        public int PhoneBookEntryID { get; set; }
        public int PhoneBookId { get; set; }
        public string PhonebookName { get; set; }
        public string EntryName { get; set; }
        public string PhoneNumber { get; set; }
    }
}