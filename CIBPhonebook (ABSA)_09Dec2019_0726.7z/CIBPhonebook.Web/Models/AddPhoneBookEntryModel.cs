﻿using DataAnnotationsExtensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CIBPhonebook.Web.Models
{
    public class AddPhoneBookEntryModel
    {
        [Range(1, int.MaxValue, ErrorMessage = "Please select a phone book for this entry")]
        public int PhoneBookId { get; set; }


        [Required(ErrorMessage = "Entry name is required")]
        public string EntryName { get; set; }


        [Required(ErrorMessage = "Phone number is required"), Digits(ErrorMessage = "Only numbers are allowed")]
        public string PhoneNumber { get; set; }

        public bool CloseModal { get; set; }
    }
}