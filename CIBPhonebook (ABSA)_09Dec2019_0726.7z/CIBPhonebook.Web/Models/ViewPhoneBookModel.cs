﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.Web.Models
{
    public class ViewPhoneBookModel
    {
        public int PhonebookId { get; set; }
        public string PhonebookName { get; set; }
    }
}