﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace CIBPhonebook.Web
{
    public class Config
    {
        public string CIBPhoneBookAPIRoot => ConfigurationManager.AppSettings[nameof(CIBPhoneBookAPIRoot)];
    }
}