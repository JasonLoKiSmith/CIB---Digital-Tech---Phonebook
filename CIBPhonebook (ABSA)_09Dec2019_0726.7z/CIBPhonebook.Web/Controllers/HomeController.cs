﻿using CIBPhonebook.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CIBPhonebook.Web.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult GetAddPhoneBookEntryModal()
        {
            AddPhoneBookEntryModel model = new AddPhoneBookEntryModel();
            return PartialView("_AddPhoneBookEntryModal", model);
        }


        [HttpPost]
        public ActionResult AddPhoneBookEntry(AddPhoneBookEntryModel model)
        {
            if (ModelState.IsValid)
            {
                APIHelper.PhoneBookEntityAPI.AddNewPhoneBookEntry(model);
                model.CloseModal = true;
                ModelState.Clear();
            }
            return PartialView("_AddPhoneBookEntryModalContent", model);
        }
    }
}