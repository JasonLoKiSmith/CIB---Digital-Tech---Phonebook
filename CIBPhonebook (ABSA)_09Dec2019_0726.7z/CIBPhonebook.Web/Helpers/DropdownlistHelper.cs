﻿using CIBPhonebook.Utilities;
using CIBPhonebook.Web.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CIBPhonebook.Web
{
    public class DropdownlistHelper
    {
        public const string PLEASE_SELECT_TEXT = "Please Select";
        public const int PLEASE_SELECT_VALUE = -1;

        public static List<SelectListItem> GetAllPhoneBooks(bool addPleaseSelect = true, string OverridePleaseSelectText = "", bool pleaseSelectSelected = false, string selectedValue = "")
        {
            List<SelectListItem> items = new List<SelectListItem>();
            StandardAPIResponse apiResponse = APIHelper.PhoneBookAPI.GetAllPhoneBooks();
            List<ViewPhoneBookModel> apiItems = new List<ViewPhoneBookModel>();
            if (apiResponse.HasSuccessResult && !apiResponse.ResultIsNull)
            {
                //'Result.Deserialise' is not a standard method but rather a extension method i added to make life easier
                apiItems = apiResponse.Result.Deserialise<List<ViewPhoneBookModel>>() ?? new List<ViewPhoneBookModel>();
            }


            items = apiItems.Select(x => new SelectListItem
            {
                Value = x.PhonebookId.ToString(),
                Text = x.PhonebookName
            }).ToList();


            if (addPleaseSelect == true)
            {
                if (pleaseSelectSelected)
                    items.Insert(0, new SelectListItem { Text = string.IsNullOrWhiteSpace(OverridePleaseSelectText) ? PLEASE_SELECT_TEXT : OverridePleaseSelectText, Value = Convert.ToString(PLEASE_SELECT_VALUE), Selected = true });
                else
                    items.Insert(0, new SelectListItem { Text = string.IsNullOrWhiteSpace(OverridePleaseSelectText) ? PLEASE_SELECT_TEXT : OverridePleaseSelectText, Value = Convert.ToString(PLEASE_SELECT_VALUE) });
            }

            if (!string.IsNullOrEmpty(selectedValue))
            {
                SelectListItem item = items.FirstOrDefault(x => x.Value == selectedValue);
                if (item != null)
                {
                    items.ForEach(x => x.Selected = false);
                    item.Selected = true;
                }
            }
            return items;
        }
    }
}