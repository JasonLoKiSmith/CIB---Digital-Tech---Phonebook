﻿using CIBPhonebook.Utilities;
using CIBPhonebook.Web.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace CIBPhonebook.Web
{
    public partial class APIHelper
    {
        public class PhoneBookAPI
        {
            public static StandardAPIResponse GetAllPhoneBooks()
            {
                HttpResponseMessage httpResponseMessage = HttpClientHelper.GetClient(x => x.CIBPhoneBookAPIRoot).GetAsync($"api/Book/{nameof(GetAllPhoneBooks)}").Result;
                return StandardAPIResponse.DeserialiseResponse(httpResponseMessage);
            }
        }
    }
}