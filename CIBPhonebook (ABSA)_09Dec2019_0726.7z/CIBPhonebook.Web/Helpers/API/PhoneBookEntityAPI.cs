﻿using CIBPhonebook.Utilities;
using CIBPhonebook.Web.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace CIBPhonebook.Web
{
    public partial class APIHelper
    {
        public class PhoneBookEntityAPI
        {
            public static StandardAPIResponse GetPhoneBookEntriesByParamsPaged(ViewPagedPhonebookRequest request)
            {
                HttpResponseMessage httpResponseMessage = HttpClientHelper.GetClient(x => x.CIBPhoneBookAPIRoot).PostAsJsonAsync($"api/Entry/{nameof(GetPhoneBookEntriesByParamsPaged)}", request).Result;
                return StandardAPIResponse.DeserialiseResponse(httpResponseMessage);
            }

            public static StandardAPIResponse GetAllPhoneBookEntries()
            {
                HttpResponseMessage httpResponseMessage = HttpClientHelper.GetClient(x => x.CIBPhoneBookAPIRoot).GetAsync($"api/Entry/{nameof(GetAllPhoneBookEntries)}").Result;
                return StandardAPIResponse.DeserialiseResponse(httpResponseMessage);
            }

            public static StandardAPIResponse AddNewPhoneBookEntry(AddPhoneBookEntryModel model)
            {
                HttpResponseMessage httpResponseMessage = HttpClientHelper.GetClient(x => x.CIBPhoneBookAPIRoot).PostAsJsonAsync($"api/Entry/{nameof(AddNewPhoneBookEntry)}", model).Result;
                return StandardAPIResponse.DeserialiseResponse(httpResponseMessage);
            }
        }
    }
}