﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace CIBPhonebook.Web
{
    public partial class APIHelper
    {
        public const string Result = "result";
        public static class HttpClientHelper
        {
            public static HttpClient GetClient(Func<Config, string> configSelector)
            {
                var client = new HttpClient
                {
                    BaseAddress = new Uri(configSelector.Invoke(new Config()))
                };
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.Timeout = TimeSpan.FromMinutes(15);
                return client;
            }
            public static HttpClient GetClientForDelete<T>(Func<Config, string> configSelector, T dto, string relativeURL, out HttpRequestMessage request)
            {
                var client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Clear();
                request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = new Uri(new Uri(configSelector.Invoke(new Config())), relativeURL),
                    Content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(dto), Encoding.UTF8, "application/json")
                };
                return client;
            }
        }
    }
}