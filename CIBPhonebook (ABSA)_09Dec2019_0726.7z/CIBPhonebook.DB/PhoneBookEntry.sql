﻿CREATE TABLE [dbo].[PhoneBookEntry]
(
	[PhoneBookEntryID] INT NOT NULL IDENTITY(1,1), 
	[PhoneBookId] INT NOT NULL,
    [EntryName] VARCHAR(4000),
	[PhoneNumber] VARCHAR(4000),
    CONSTRAINT [PK_PhoneBookEntry] PRIMARY KEY CLUSTERED ([PhoneBookEntryID] ASC), 
    CONSTRAINT [FK_PhoneBookEntry_PhoneBook] FOREIGN KEY ([PhoneBookId]) REFERENCES [Phonebook]([PhonebookID]),
	
)
