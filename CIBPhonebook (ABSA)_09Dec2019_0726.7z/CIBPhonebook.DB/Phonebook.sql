﻿CREATE TABLE [dbo].[Phonebook]
(
	[PhonebookID] INT NOT NULL IDENTITY(1,1), 
    [PhonebookName] VARCHAR(4000) NOT NULL,
    CONSTRAINT [PK_SendEmail] PRIMARY KEY CLUSTERED ([PhonebookID] ASC),
)

