﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
IF(SELECT COUNT(1) FROM [Phonebook]) = 0
BEGIN

        SET IDENTITY_INSERT [dbo].[Phonebook] ON 
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (1, N'Work')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (2, N'Personal')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (3, N'Friends')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (4, N'Family')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (5, N'Colleagues')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (6, N'Random')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (7, N'Gathering')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (8, N'Racing')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (9, N'Building')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (10, N'Ski')
        INSERT [dbo].[Phonebook] ([PhonebookID], [PhonebookName]) VALUES (11, N'Roller Coaster')
        SET IDENTITY_INSERT [dbo].[Phonebook] OFF

        SET IDENTITY_INSERT [dbo].[PhoneBookEntry] ON 
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (1, 1, N'John', N'(912) 295-5944')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (2, 1, N'Susan', N'(207) 878-3538')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (3, 1, N'Anton', N'(765) 465-4076')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (4, 1, N'Justin', N'(269) 426-3414')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (5, 1, N'Jason', N'(269) 426-3414')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (6, 2, N'Sonja', N'(912) 295-5944')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (7, 2, N'Nicky', N'(207) 878-3538')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (8, 2, N'NK', N'(765) 465-4076')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (9, 2, N'Gerhard', N'(269) 426-3414')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (10, 3, N'Rynhardt', N'(810) 325-1507')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (11, 3, N'Robert', N'(402) 924-3826')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (12, 3, N'Degracia', N'(912) 295-5944')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (13, 4, N'Shrikant', N'(207) 878-3538')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (14, 4, N'Carl', N'(765) 465-4076')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (15, 4, N'Elmarie', N'(269) 426-3414')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (16, 4, N'Maxi', N'(810) 325-1507')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (17, 5, N'rdon', N'(402) 924-3826')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (18, 5, N'Pieter', N'(912) 295-5944')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (19, 5, N'Isabel', N'(207) 878-3538')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (20, 5, N'Elize', N'(765) 465-4076')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (21, 6, N'Isabel', N'(269) 426-3414')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (22, 6, N'Stephan', N'(810) 325-1507')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (23, 6, N'Rian', N'(402) 924-3826')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (24, 6, N'Celeste', N'(912) 295-5944')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (25, 7, N'Pierre', N'(207) 878-3538')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (26, 7, N'Yolande', N'(765) 465-4076')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (27, 7, N'Alicia', N'(269) 426-3414')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (28, 9, N'Ian', N'(810) 325-1507')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (29, 9, N'Anouk', N'(765) 465-4076')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (30, 9, N'Mike', N'(912) 295-5944')
        INSERT [dbo].[PhoneBookEntry] ([PhoneBookEntryID], [PhoneBookId], [EntryName], [PhoneNumber]) VALUES (31, 9, N'Mila', N'(207) 878-3538')
        SET IDENTITY_INSERT [dbo].[PhoneBookEntry] OFF

END