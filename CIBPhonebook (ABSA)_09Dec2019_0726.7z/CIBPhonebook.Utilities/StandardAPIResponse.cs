﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CIBPhonebook.Utilities
{
    public sealed class StandardAPIResponse
    {
        private StandardAPIResponse(HttpResponseMessage httpResponse)
        {
            this.HttpResponseMessage = httpResponse;
        }

        /// <summary>
        /// only available while debugging
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        private readonly HttpResponseMessage HttpResponseMessage;

        public List<string> Errors { get; set; } = new List<string>();
        public int StatusCode { get; set; }
        public string StatusCodeMessage { get; set; } = "";
        public JToken Result { get; set; }


        public bool ResultIsNull
        {
            get
            {
                if (HasSuccessResult)
                    return true;
                else if (Result == null)
                    return true;
                else if (Result.Type == JTokenType.Null || string.IsNullOrWhiteSpace(Convert.ToString(Result)))
                    return true;
                else
                    return false;
            }
        }
        public HttpResponseMessage GetHttpResponseMessage()
        {
            return this.HttpResponseMessage;
        }


        public bool HasSuccessResult => Errors.Count == 0 && StatusCode == (int)HttpStatusCode.OK;

        public static StandardAPIResponse DeserialiseResponse(HttpResponseMessage httpResponse)
        {
            // the reason for manually reading and populating the 'StandardAPIResponse' object is because 
            //StandardAPIResponse has got a private constructor which forces you to use the  'DeserialiseResponse' method
            //and as a side effect you now also cannot use something like JsonConvert.DeserialiseObject because it requires a public constructor on a object.

            StandardAPIResponse response = new StandardAPIResponse(httpResponse);
            response.StatusCode = (int)httpResponse.StatusCode;
            response.StatusCodeMessage = httpResponse.StatusCode.ToString();
            JObject resultJObject = JObject.Parse(httpResponse.Content?.ReadAsStringAsync().Result);
            if (resultJObject.Children().Count() > 0)
            {

                if (resultJObject.Children().FirstOrDefault(x => x.Path.Equals(nameof(Result), StringComparison.InvariantCultureIgnoreCase)) != null)
                {
                    JToken resultToken = resultJObject.Children().FirstOrDefault(x => x.Path.Equals(nameof(Result), StringComparison.InvariantCultureIgnoreCase));
                    if (resultToken is JProperty)
                    {
                        response.Result = ((JProperty)resultToken).Value;
                    }
                }


                if (resultJObject.Children().FirstOrDefault(x => x.Path.Equals(nameof(Errors), StringComparison.InvariantCultureIgnoreCase)) != null)
                {
                    JToken resultToken = resultJObject.Children().FirstOrDefault(x => x.Path.Equals(nameof(Errors), StringComparison.InvariantCultureIgnoreCase));
                    if (resultToken is JProperty)
                    {
                        response.Errors = JsonConvert.DeserializeObject<List<string>>(Convert.ToString(((JProperty)resultToken).Value));
                    }
                }

            }

            if ((int)response.GetHttpResponseMessage().StatusCode >= 401)
            {
                if (response.Errors == null)
                    response.Errors = new List<string>();

                response.Errors.Add($"HttpRequest returned a {(int)response.GetHttpResponseMessage().StatusCode} response");
            }
            return response;
        }
    }
}


