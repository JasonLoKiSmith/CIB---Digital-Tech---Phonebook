﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIBPhonebook.Utilities
{
    public static class JTokenExtensions
    {
        public static T Deserialise<T>(this JToken token)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(token)) && token.Type != JTokenType.Null)
            {
                return JsonConvert.DeserializeObject<T>(Convert.ToString(token));
            }
            else return default(T);
        }

    }
}