﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.API.Core
{
    internal class ApiResponseResult
    {
        public List<string> Errors { get; set; }
        public int StatusCode { get; set; }
        public string StatusCodeMessage { get; set; }
        public object Result { get; set; }
        public ApiResponseResult(object result, List<string> errors)
        {
            Errors = errors;
            Result = result;
        }
    }
}