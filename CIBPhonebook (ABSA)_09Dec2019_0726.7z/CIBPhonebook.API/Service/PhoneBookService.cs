﻿using CIBPhonebook.API.Models;
using CIBPhonebook.API.Models.PhoneBook;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace CIBPhonebook.API.Service
{
    public class PhoneBookService
    {
        private DB db;

        public PhoneBookService(DB db)
        {
            this.db = db;
        }


        public Task<List<ViewPhoneBookModel>> GetPhoneBooks()
        {
            return Task.Run(() =>
            {
                List<ViewPhoneBookModel> phoneBooks = db.Phonebooks.Select(x => new ViewPhoneBookModel
                {
                    PhonebookId = x.PhonebookID,
                    PhonebookName = x.PhonebookName
                }).ToList();

                return phoneBooks;
            });

        }

        public Task<int> AddPhoneBookModel(AddPhoneBookModel model)
        {
            return Task.Run(() =>
            {
                if (!string.IsNullOrWhiteSpace(model.Name))
                {
                    Phonebook phonebook = new Phonebook() { PhonebookName = model.Name };
                    db.Phonebooks.Add(phonebook);
                    db.SaveChanges();
                    return phonebook.PhonebookID;
                }
                else return 0;
            });
        }
    }
}