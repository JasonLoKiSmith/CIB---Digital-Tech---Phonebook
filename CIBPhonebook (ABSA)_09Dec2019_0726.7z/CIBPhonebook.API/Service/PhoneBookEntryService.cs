﻿using CIBPhonebook.API.Models.Entry;
using CIBPhonebook.API.Models.Entry.Paging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using PagedList;

namespace CIBPhonebook.API.Service
{
    public class PhoneBookEntryService
    {
        private DB db;

        public PhoneBookEntryService(DB db)
        {
            this.db = db;
        }


        public Task<List<ViewPhoneBookEntryModel>> GetAllPhoneBookEntries()
        {
            return Task.Run(() =>
            {
                List<ViewPhoneBookEntryModel> phoneBookEntries = db.PhoneBookEntries.Select(x => new ViewPhoneBookEntryModel
                {
                    PhoneBookEntryID = x.PhoneBookEntryID,
                    PhoneBookId = x.PhoneBookId,
                    EntryName = x.EntryName,
                    PhoneNumber = x.PhoneNumber
                }).ToList();

                return phoneBookEntries;
            });

        }

        public Task<int> AddPhoneBookEntry(AddPhoneBookEntryModel model)
        {
            return Task.Run(() =>
            {
                if (!string.IsNullOrWhiteSpace(model.EntryName))
                {
                    PhoneBookEntry phonebookEntry = new PhoneBookEntry()
                    {
                        PhoneBookId = model.PhoneBookId,
                        EntryName = model.EntryName,
                        PhoneNumber = model.PhoneNumber
                    };
                    db.PhoneBookEntries.Add(phonebookEntry);
                    db.SaveChanges();
                    return phonebookEntry.PhoneBookEntryID;
                }
                else return 0;
            });
        }


        
        public Task<GetPagedPhonebookEntriesByPhonebookIdResponseDTO> GetPhoneBookEntriesByParamsPaged(GetPagedPhonebookEntriesByPhonebookIdRequestDTO filterDTO)
        {
            return Task.Run(() =>
            {
                List<ViewPagedPhoneBookEntryModel> Data = new List<ViewPagedPhoneBookEntryModel>();
                int TotalRecords = 0;

                var baseQuery = (from pbe in db.PhoneBookEntries
                                 join pb in db.Phonebooks on pbe.PhoneBookId equals pb.PhonebookID
                                 select new ViewPagedPhoneBookEntryModel
                                 {
                                     PhoneBookId = pbe.PhoneBookId,
                                     PhoneBookEntryID = pbe.PhoneBookEntryID,
                                     EntryName = pbe.EntryName,
                                     PhonebookName = pb.PhonebookName,
                                     PhoneNumber = pbe.PhoneNumber
                                 });


                if (filterDTO.PhoneBookId > 0)
                    baseQuery = baseQuery.Where(x => x.PhoneBookId == filterDTO.PhoneBookId);


                if (!string.IsNullOrWhiteSpace(filterDTO.SearchAll))
                {
                    baseQuery = baseQuery.Where(x =>
                     x.PhoneNumber.ToString().Contains(filterDTO.SearchAll) ||
                     x.EntryName.ToString().Contains(filterDTO.SearchAll) ||
                     x.PhonebookName.ToString().Contains(filterDTO.SearchAll));
                }


                IQueryable<ViewPagedPhoneBookEntryModel> finalBaseQuery = (from bq in baseQuery
                                                                           select bq).OrderByDescending(x => x.PhoneBookEntryID);
                TotalRecords = finalBaseQuery.Count();

                if (filterDTO.PageSize <= 0)
                    filterDTO.PageSize = GetPagedPhonebookEntriesByPhonebookIdRequestDTO.DEFAULT_PAGE_SIZE;

                if (filterDTO.PageNumber <= 0)
                    filterDTO.PageNumber = 1;

                Data = finalBaseQuery.ToPagedList(filterDTO.PageNumber, filterDTO.PageSize).ToList();

                return new GetPagedPhonebookEntriesByPhonebookIdResponseDTO
                {
                    TotalRecords = TotalRecords,
                    PagedData = Data
                };
            });
        }
    }
}