﻿using CIBPhonebook.API.Models;
using CIBPhonebook.API.Models.PhoneBook;
using CIBPhonebook.API.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace CIBPhonebook.API.Controllers
{
    public class BookController : ApiController
    {
        private readonly PhoneBookService _phoneBookService;

        public BookController()
        {
            DB db = new DB();
            _phoneBookService = new PhoneBookService(db);
        }
        /// <summary>
        /// GET: all programme managers
        /// </summary>
        [HttpGet, ResponseType(typeof(List<ViewPhoneBookModel>))]
        public async Task<IHttpActionResult> GetAllPhoneBooks()
        {
            return Ok(await _phoneBookService.GetPhoneBooks());
        }

        [HttpPost]
        public async Task<IHttpActionResult> AddNewPhoneBookEntry([FromBody] AddPhoneBookModel model)
        {
            return Ok(await _phoneBookService.AddPhoneBookModel(model));
        }
    }
}
