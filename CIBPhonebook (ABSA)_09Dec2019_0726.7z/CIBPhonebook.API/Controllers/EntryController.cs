﻿using CIBPhonebook.API.Models;
using CIBPhonebook.API.Models.Entry;
using CIBPhonebook.API.Models.Entry.Paging;
using CIBPhonebook.API.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace CIBPhonebook.API.Controllers
{
    public class EntryController : ApiController
    {
        private readonly PhoneBookEntryService _phoneBookEntryService;
        public EntryController()
        {
            DB db = new DB();
            _phoneBookEntryService = new PhoneBookEntryService(db);
        }


        /// <summary>
        /// GET: all programme managers
        /// </summary>
        [HttpGet, ResponseType(typeof(List<ViewPhoneBookEntryModel>))]
        public async Task<IHttpActionResult> GetAllPhoneBookEntries()
        {
            return Ok(await _phoneBookEntryService.GetAllPhoneBookEntries());
        }

        [HttpPost]
        public async Task<IHttpActionResult> AddNewPhoneBookEntry([FromBody] AddPhoneBookEntryModel model)
        {
            return Ok(await _phoneBookEntryService.AddPhoneBookEntry(model));
        }


        [HttpPost]
        public async Task<IHttpActionResult> GetPhoneBookEntriesByParamsPaged([FromBody] GetPagedPhonebookEntriesByPhonebookIdRequestDTO model)
        {
            return Ok(await _phoneBookEntryService.GetPhoneBookEntriesByParamsPaged(model));
        }


    }
}
