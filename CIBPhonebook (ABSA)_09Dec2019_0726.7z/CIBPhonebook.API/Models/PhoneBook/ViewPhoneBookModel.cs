﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.API.Models.PhoneBook
{
    public class ViewPhoneBookModel
    {
        public int PhonebookId { get; set; }
        public string PhonebookName { get; set; }

    }
}