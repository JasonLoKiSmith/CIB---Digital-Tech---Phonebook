﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.API.Models.PhoneBook
{
    public class AddPhoneBookModel
    {
        public string Name { get; set; }
    }
}