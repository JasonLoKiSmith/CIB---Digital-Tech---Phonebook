﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.API.Models.Entry.Paging
{
    public class ViewPagedPhoneBookEntryModel
    {
        public int PhoneBookEntryID { get; set; }
        public int PhoneBookId { get; set; }
        public string PhonebookName { get; set; }
        public string EntryName { get; set; }
        public string PhoneNumber { get; set; }
    }
}