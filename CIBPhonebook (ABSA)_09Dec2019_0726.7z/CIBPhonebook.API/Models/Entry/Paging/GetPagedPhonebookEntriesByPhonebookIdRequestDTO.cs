﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.API.Models.Entry.Paging
{
    public class GetPagedPhonebookEntriesByPhonebookIdRequestDTO
    {
        public const int DEFAULT_PAGE_SIZE = 20;
        public string SearchAll { get; set; }
        public int PageSize { get; set; }
        public int PageNumber { get; set; }

        //Filter Parameters
        public int PhoneBookId { get; set; }
    }
}