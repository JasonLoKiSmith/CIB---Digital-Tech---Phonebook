﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIBPhonebook.API.Models.Entry.Paging
{
    public class GetPagedPhonebookEntriesByPhonebookIdResponseDTO
    {
        public int TotalRecords { get; set; }
        public List<ViewPagedPhoneBookEntryModel> PagedData { get; set; }
    }
}